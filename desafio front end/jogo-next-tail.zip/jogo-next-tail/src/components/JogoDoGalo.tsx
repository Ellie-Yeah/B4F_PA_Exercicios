"use client"
//Cria aqui o teu componente
import { useJogoDoGalo } from "../hooks/useJogoDoGalo";

const casaVazia = " "
export function JogoDoGalo() {
    const {
        jogo,
        verificarFimDoJogo,
        adicionarJogada,
        verificarVencedor,
        reiniciarJogo
    } = useJogoDoGalo()

    return (
        <div>

        </div>
    )
}